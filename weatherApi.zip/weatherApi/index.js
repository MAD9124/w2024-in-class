import express from "express";

const walks = [
  {
    id: 1,
    startTime: new Date("2024-01-01T14:00"),
    endTime: new Date("2024-01-01T14:30"),
    city: "Ottawa",
  },
  {
    id: 2,
    startTime: new Date("2024-01-03T15:00"),
    endTime: new Date("2024-01-03T15:45"),
    city: "Ottawa",
  },
];

const app = express();
app.use(express.json());

app.get("/api/walk/", (_req, res) => {
  res.json({
    data: walks,
  });
});

app.get("/api/walk/:id", (req, res) => {
  const { id } = req.params;
  const walk = walks.find((walk) => Number(id) === walk.id);

  if (!walk) {
    res.status(404).json({
      error: `Walk with id ${id} not found`,
    });
    return;
  }

  res.json({
    data: walk,
  });
});

app.post("/api/walk/", (req, res) => {
  const { startTime, endTime, city } = req.body;
  const id = (walks[walks.length - 1]?.id ?? 0) + 1;

  const newWalk = {
    id,
    startTime: new Date(startTime),
    endTime: new Date(endTime),
    city,
  };
  walks.push(newWalk);

  res.status(201).json({
    data: newWalk,
  });
});

app.patch("/api/walk/:id", (req, res) => {
  const { id } = req.params;
  const { startTime, endTime, city } = req.body;
  const walk = walks.find((walk) => Number(id) === walk.id);

  if (!walk) {
    res.status(404).json({
      error: `Walk with id ${id} not found`,
    });
    return;
  }

  if (startTime) walk.startTime = startTime;
  if (startTime) walk.endTime = endTime;
  if (startTime) walk.city = city;

  res.status(201).json({
    data: walk,
  });
});

app.delete("/api/walk/:id", (req, res) => {
  const { id } = req.params;
  const walkIndex = walks.findIndex((walk) => Number(id) === walk.id);

  if (walkIndex === -1) {
    res.status(404).json({
      error: `Walk with id ${id} not found`,
    });
    return;
  }

  const [deletedWalk] = walks.splice(walkIndex, 1);
  res.json({ data: deletedWalk });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`App listening on port ${PORT}`);
});
